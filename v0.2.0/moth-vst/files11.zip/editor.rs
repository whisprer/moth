//! Moth — vizia GUI editor.
//!
//! Signal chain flows left to right, matching the DSP architecture:
//! Exciter → Vibrator → Body → [Mix] → Character → Space → Master
//!
//! Phase 1: grouped sliders with section headers, nih-plug theme.
//! Phase 2: custom dark theme with amber accents (the moth aesthetic).

use nih_plug::prelude::*;
use nih_plug_vizia::vizia::prelude::*;
use nih_plug_vizia::widgets::*;
use nih_plug_vizia::{assets, create_vizia_editor, ViziaState, ViziaTheming};
use std::sync::Arc;

use crate::MothParams;

// ── Window size ─────────────────────────────────────────────────────────────

/// Editor window: wide enough for 7 signal-chain columns.
const EDITOR_WIDTH: u32 = 920;
const EDITOR_HEIGHT: u32 = 500;

// ── Custom stylesheet ───────────────────────────────────────────────────────

/// Moth dark theme — amber on charcoal, warm and alive.
const STYLE: &str = r#"
* {
    font-size: 13;
}

.moth-root {
    background-color: #1a1816;
    child-space: 0px;
    width: 1s;
    height: 1s;
}

/* ── Header bar ── */

.header {
    height: auto;
    width: 1s;
    child-top: 8px;
    child-bottom: 8px;
    child-left: 16px;
    child-right: 16px;
    col-between: 8px;
    background-color: #1e1c19;
    border-color: #2a2724;
    border-width: 0px 0px 1px 0px;
}

.title {
    color: #d4a855;
    font-size: 20;
    width: auto;
    height: auto;
}

.subtitle {
    color: #6b6560;
    font-size: 11;
    width: auto;
    height: auto;
    child-top: 1s;
    child-bottom: 0px;
}

.vendor {
    color: #6b6560;
    font-size: 11;
    width: auto;
    height: auto;
    child-left: 1s;
    child-top: 1s;
    child-bottom: 0px;
}

/* ── Signal chain container ── */

.signal-chain {
    width: 1s;
    height: 1s;
    child-space: 0px;
    child-top: 4px;
    child-bottom: 8px;
    child-left: 8px;
    child-right: 8px;
    col-between: 2px;
}

/* ── Section columns ── */

.section {
    width: 1s;
    height: 1s;
    child-space: 0px;
    child-left: 8px;
    child-right: 8px;
    child-top: 4px;
    row-between: 2px;
}

.section-narrow {
    width: 1s;
    max-width: 120px;
    height: 1s;
    child-space: 0px;
    child-left: 8px;
    child-right: 8px;
    child-top: 4px;
    row-between: 2px;
}

.section-header {
    color: #d4a855;
    font-size: 10;
    width: 1s;
    height: auto;
    child-left: 1s;
    child-right: 1s;
    child-bottom: 6px;
}

.section-header-muted {
    color: #8a7a65;
    font-size: 10;
    width: 1s;
    height: auto;
    child-left: 1s;
    child-right: 1s;
    child-bottom: 6px;
}

.section-divider {
    width: 1px;
    height: 1s;
    background-color: #2a2724;
}

/* ── Parameter rows ── */

.param-row {
    width: 1s;
    height: auto;
    row-between: 1px;
    child-bottom: 4px;
}

.param-label {
    color: #8a8580;
    font-size: 11;
    width: 1s;
    height: auto;
    child-bottom: 2px;
}

.param-row .widget {
    width: 1s;
    height: 20px;
}

/* ── Footer (signal chain indicator) ── */

.footer {
    height: auto;
    width: 1s;
    child-left: 1s;
    child-right: 1s;
    child-top: 2px;
    child-bottom: 6px;
    border-color: #2a2724;
    border-width: 1px 0px 0px 0px;
    col-between: 4px;
}

.footer-text {
    color: #4a4640;
    font-size: 9;
    width: auto;
    height: auto;
}

/* ── Override nih-plug widget colours for dark theme ── */

param-slider {
    background-color: #252320;
    border-radius: 3px;
}

param-slider .fill {
    background-color: #d4a855;
}

generic-ui .row .label {
    color: #8a8580;
    font-size: 11;
}
"#;

// ── Data model ──────────────────────────────────────────────────────────────

/// Vizia lens for accessing plugin parameters from the GUI.
#[derive(Lens)]
struct Data {
    params: Arc<MothParams>,
}

impl Model for Data {}

// ── Public API ──────────────────────────────────────────────────────────────

/// Create the default editor state (initial window size).
pub(crate) fn default_state() -> Arc<ViziaState> {
    ViziaState::new(|| (EDITOR_WIDTH, EDITOR_HEIGHT))
}

/// Create the vizia editor.
pub(crate) fn create(
    params: Arc<MothParams>,
    editor_state: Arc<ViziaState>,
) -> Option<Box<dyn Editor>> {
    create_vizia_editor(editor_state, ViziaTheming::Custom, move |cx, _| {
        assets::register_noto_sans_light(cx);
        assets::register_noto_sans_thin(cx);

        cx.add_stylesheet(STYLE).expect("moth: failed to add stylesheet");

        Data {
            params: params.clone(),
        }
        .build(cx);

        // ── Root container ──
        VStack::new(cx, |cx| {
            // ── Header ──
            HStack::new(cx, |cx| {
                Label::new(cx, "MOTH").class("title");
                Label::new(cx, "physical modelling synthesiser").class("subtitle");
                Label::new(cx, "RYO Modular").class("vendor");
            })
            .class("header");

            // ── Signal chain sections (left → right) ──
            HStack::new(cx, |cx| {
                // ─── EXCITER ───
                VStack::new(cx, |cx| {
                    Label::new(cx, "EXCITER").class("section-header");
                    param_row(cx, "Morph", |p| &p.exciter_morph);
                    param_row(cx, "Tilt", |p| &p.spectral_tilt);
                    param_row(cx, "Stochastic", |p| &p.stochasticity);
                })
                .class("section");

                Element::new(cx).class("section-divider");

                // ─── VIBRATOR ───
                VStack::new(cx, |cx| {
                    Label::new(cx, "VIBRATOR").class("section-header");
                    param_row(cx, "Damping", |p| &p.vib_damping);
                    param_row(cx, "Brightness", |p| &p.vib_brightness);
                    param_row(cx, "Dispersion", |p| &p.vib_dispersion);
                    param_row(cx, "Position", |p| &p.position);
                })
                .class("section");

                Element::new(cx).class("section-divider");

                // ─── BODY ───
                VStack::new(cx, |cx| {
                    Label::new(cx, "BODY").class("section-header");
                    param_row(cx, "Geometry", |p| &p.body_geometry);
                    param_row(cx, "Brightness", |p| &p.body_brightness);
                    param_row(cx, "Damping", |p| &p.body_damping);
                    param_row(cx, "Size", |p| &p.body_size);
                })
                .class("section");

                Element::new(cx).class("section-divider");

                // ─── MIX ───
                VStack::new(cx, |cx| {
                    Label::new(cx, "MIX").class("section-header-muted");
                    param_row(cx, "Bleed", |p| &p.exciter_bleed);
                    param_row(cx, "Body Mix", |p| &p.body_mix);
                })
                .class("section-narrow");

                Element::new(cx).class("section-divider");

                // ─── CHARACTER (non-lin) ───
                VStack::new(cx, |cx| {
                    Label::new(cx, "CHARACTER").class("section-header");
                    param_row(cx, "Drive", |p| &p.nl_drive);
                    param_row(cx, "Tape", |p| &p.nl_tape);
                    param_row(cx, "Tube", |p| &p.nl_tube);
                    param_row(cx, "Warmth", |p| &p.nl_warmth);
                    param_row(cx, "Tone", |p| &p.nl_tone);
                })
                .class("section");

                Element::new(cx).class("section-divider");

                // ─── SPACE (spatial) ───
                VStack::new(cx, |cx| {
                    Label::new(cx, "SPACE").class("section-header");
                    param_row(cx, "Room", |p| &p.room_size);
                    param_row(cx, "Reverb", |p| &p.room_mix);
                })
                .class("section-narrow");

                Element::new(cx).class("section-divider");

                // ─── MASTER ───
                VStack::new(cx, |cx| {
                    Label::new(cx, "OUT").class("section-header");
                    param_row(cx, "Master", |p| &p.master_gain);
                })
                .class("section-narrow");
            })
            .class("signal-chain");

            // ── Footer: signal chain indicator ──
            HStack::new(cx, |cx| {
                Label::new(cx, "exciter → vibrator → body → nonlin → spatial → out")
                    .class("footer-text");
            })
            .class("footer");
        })
        .class("moth-root");

        ResizeHandle::new(cx);
    })
}

// ── Helpers ─────────────────────────────────────────────────────────────────

/// Create a labelled parameter slider row.
///
/// Uses the nih-plug ParamSlider with FromLeft style, matching the
/// mockup's horizontal slider aesthetic.
fn param_row<P, FMap>(cx: &mut Context, label: &str, params_to_param: FMap)
where
    P: Param + 'static,
    FMap: 'static + Fn(&MothParams) -> &P + Copy,
{
    VStack::new(cx, move |cx| {
        Label::new(cx, label).class("param-label");
        ParamSlider::new(cx, Data::params, params_to_param)
            .set_style(ParamSliderStyle::FromLeft)
            .class("widget");
    })
    .class("param-row");
}
