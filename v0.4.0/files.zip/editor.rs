//! Moth — Shadow Hills edition (Step 1: faceplate background + positioned sliders)
//!
//! This first version just gets the faceplate showing as the background
//! with all parameter sliders positioned over the correct slots.
//! Animated knobs and VU needle come in step 2.

use nih_plug::prelude::*;
use nih_plug_vizia::vizia::prelude::*;
use nih_plug_vizia::vizia::vg;
use nih_plug_vizia::widgets::*;
use nih_plug_vizia::{create_vizia_editor, ViziaState, ViziaTheming};
use std::sync::Arc;
use crate::MothParams;

// ─── Embedded faceplate ─────────────────────────────────────────────────────

const FACEPLATE_PNG: &[u8] = include_bytes!("../assets/faceplate.png");

const FW: u32 = 1344;
const FH: u32 = 797;
const EDITOR_WIDTH: u32 = FW;
const EDITOR_HEIGHT: u32 = FH;

// ─── CSS ────────────────────────────────────────────────────────────────────
//
// The faceplate provides all the visual chrome — labels, panels, decorative
// knobs, the moth illustration. We just need to position interactive sliders
// over the slots painted into the image.

const STYLE: &str = r#"
* { font-size: 11; color: #c4a55a; }

.moth-root {
    background-color: #112216;
    width: 1s; height: 1s;
    child-space: 0px;
}

.faceplate-bg {
    width: 1s; height: 1s;
    child-space: 0px;
}

/* Slider widget — just a thin coloured fill bar that sits over the painted slot */
.slot {
    width: 130px;
    height: 14px;
    background-color: #0e1711;
    border-radius: 2px;
    position-type: self-directed;
}

.slot-wide {
    width: 140px;
    height: 14px;
    background-color: #0e1711;
    border-radius: 2px;
    position-type: self-directed;
}

param-slider {
    background-color: rgba(0, 0, 0, 0);
    color: #c4a55a;
    font-size: 10;
}
param-slider .fill {
    background-color: #c4a55a;
    border-radius: 2px;
}
param-slider.sl-purple { color: #9b7ad8; }
param-slider.sl-purple .fill { background-color: #9b7ad8; }
param-slider.sl-teal { color: #5dcaa5; }
param-slider.sl-teal .fill { background-color: #5dcaa5; }
"#;

// ─── Faceplate background view ──────────────────────────────────────────────

struct FaceplateBg {
    image_id: std::cell::Cell<Option<vg::ImageId>>,
}

impl FaceplateBg {
    pub fn new(cx: &mut Context) -> Handle<'_, Self> {
        Self { image_id: std::cell::Cell::new(None) }.build(cx, |_| {})
    }
}

impl View for FaceplateBg {
    fn element(&self) -> Option<&'static str> { Some("faceplate-bg") }

    fn draw(&self, cx: &mut DrawContext, canvas: &mut Canvas) {
        let b = cx.bounds();
        let (x, y, w, h) = (b.x, b.y, b.w, b.h);

        // Lazy-load the faceplate image on first draw
        let id = if let Some(id) = self.image_id.get() {
            id
        } else {
            // Decode PNG using image crate
            use std::io::Cursor;
            let img = match image::load(Cursor::new(FACEPLATE_PNG), image::ImageFormat::Png) {
                Ok(i) => i,
                Err(_) => return,
            };
            let rgba = img.to_rgba8();
            let (iw, ih) = rgba.dimensions();
            let pixels: Vec<vg::rgb::RGBA8> = rgba.as_raw().chunks_exact(4)
                .map(|c| vg::rgb::RGBA8::new(c[0], c[1], c[2], c[3]))
                .collect();
            let imgref = vg::imgref::Img::new(pixels, iw as usize, ih as usize);
            match canvas.create_image(vg::ImageSource::from(imgref), vg::ImageFlags::empty()) {
                Ok(id) => { self.image_id.set(Some(id)); id },
                Err(_) => return,
            }
        };

        // Draw the faceplate filling our bounds
        let mut p = vg::Path::new();
        p.rect(x, y, w, h);
        canvas.fill_path(&p, &vg::Paint::image(id, x, y, w, h, 0.0, 1.0));
    }
}

// ─── Data model ─────────────────────────────────────────────────────────────

#[derive(Lens)]
struct Data { params: Arc<MothParams> }
impl Model for Data {}

pub(crate) fn default_state() -> Arc<ViziaState> {
    ViziaState::new(|| (EDITOR_WIDTH, EDITOR_HEIGHT))
}

// ─── Slot positions (faceplate-pixel space) ─────────────────────────────────
//
// Each tuple: (x, y, width). The slot height is always 14px and centred on y.

struct Slot { x: i32, y: i32, w: i32, color: &'static str }

fn slot(x: i32, y: i32, color: &'static str) -> Slot { Slot { x, y, w: 130, color } }
fn slot_wide(x: i32, y: i32, color: &'static str) -> Slot { Slot { x, y, w: 140, color } }

// ─── Editor creation ────────────────────────────────────────────────────────

pub(crate) fn create(
    params: Arc<MothParams>,
    editor_state: Arc<ViziaState>,
) -> Option<Box<dyn Editor>> {
    create_vizia_editor(editor_state, ViziaTheming::Custom, move |cx, _| {
        cx.add_stylesheet(STYLE).expect("moth: stylesheet");
        Data { params: params.clone() }.build(cx);

        // Root: stack the faceplate background, then absolutely-positioned sliders on top
        ZStack::new(cx, |cx| {
            // Layer 1: the faceplate image (covers entire window)
            FaceplateBg::new(cx).class("faceplate-bg");

            // Layer 2: each slider positioned absolutely over its painted slot.
            // Vizia uses left/top with position-type self-directed for absolute.

            // EXCITER column (x=107)
            place_slider(cx, "amber",  107, 295, 130, |p| &p.exciter_morph);
            place_slider(cx, "purple", 107, 339, 130, |p| &p.spectral_tilt);
            place_slider(cx, "purple", 107, 389, 130, |p| &p.stochasticity);

            // VIBRATOR column (x=290)
            place_slider(cx, "amber",  290, 293, 130, |p| &p.vib_damping);
            place_slider(cx, "purple", 290, 341, 130, |p| &p.vib_brightness);
            place_slider(cx, "teal",   290, 391, 130, |p| &p.vib_dispersion);
            place_slider(cx, "teal",   290, 439, 130, |p| &p.position);

            // BODY column (x=470)
            place_slider(cx, "amber",  470, 321, 130, |p| &p.body_geometry);
            place_slider(cx, "purple", 470, 370, 130, |p| &p.body_brightness);
            place_slider(cx, "teal",   470, 417, 130, |p| &p.body_damping);
            place_slider(cx, "teal",   470, 467, 130, |p| &p.body_size);

            // MIX column (x=635)
            place_slider(cx, "teal",   635, 145, 140, |p| &p.exciter_bleed);
            place_slider(cx, "amber",  635, 195, 140, |p| &p.body_mix);

            // CHARACTER column (x=800)
            place_slider(cx, "amber",  800, 294, 130, |p| &p.nl_drive);
            place_slider(cx, "amber",  800, 343, 130, |p| &p.nl_tape);
            place_slider(cx, "amber",  800, 391, 130, |p| &p.nl_tube);
            place_slider(cx, "purple", 800, 439, 130, |p| &p.nl_warmth);
            place_slider(cx, "teal",   800, 487, 130, |p| &p.nl_tone);

            // SPACE column (x=970)
            place_slider(cx, "amber",  970, 292, 130, |p| &p.room_size);
            place_slider(cx, "teal",   970, 340, 130, |p| &p.room_mix);

            // (Master gain has no slot — only the VU meter, which we'll add next step.
            //  For now, accessible via DAW generic param panel.)

        }).class("moth-root");

        ResizeHandle::new(cx);
    })
}

/// Place a slider absolutely positioned at the given faceplate-pixel coordinates.
/// `cx_px`, `cy_px`: centre of the slot in the original faceplate pixels.
/// `w_px`: slot width.
fn place_slider<P, FMap>(
    cx: &mut Context,
    color: &'static str,
    cx_px: i32,
    cy_px: i32,
    w_px: i32,
    params_to_param: FMap,
)
where
    P: Param + 'static,
    FMap: 'static + Fn(&Arc<MothParams>) -> &P + Copy,
{
    let h_px = 14;
    let left = cx_px - w_px / 2;
    let top = cy_px - h_px / 2;
    let cls = match color {
        "purple" => "sl-purple",
        "teal"   => "sl-teal",
        _        => "sl-amber",
    };

    HStack::new(cx, move |cx| {
        ParamSlider::new(cx, Data::params, params_to_param)
            .set_style(ParamSliderStyle::FromLeft)
            .class(cls)
            .width(Pixels(w_px as f32))
            .height(Pixels(h_px as f32));
    })
    .position_type(PositionType::SelfDirected)
    .left(Pixels(left as f32))
    .top(Pixels(top as f32))
    .width(Pixels(w_px as f32))
    .height(Pixels(h_px as f32));
}
