//! Moth — Ableton-style parameter editor.
//!
//! Uses nih-plug's GenericUi widget with custom dark CSS styling
//! to produce a clean, professional parameter grid.

use nih_plug::prelude::*;
use nih_plug_vizia::vizia::prelude::*;
use nih_plug_vizia::widgets::*;
use nih_plug_vizia::{assets, create_vizia_editor, ViziaState, ViziaTheming};
use std::sync::Arc;

use crate::MothParams;

const EDITOR_WIDTH: u32 = 780;
const EDITOR_HEIGHT: u32 = 480;

// ── Ableton-inspired dark theme ─────────────────────────────────────────────
// Charcoal background, warm grey panels, amber/yellow parameter highlights,
// cyan accents on active elements.

const STYLE: &str = r#"
* {
    font-size: 12;
    color: #b3b3b3;
}

.moth-root {
    background-color: #1e1e1e;
    child-space: 0px;
    width: 1s;
    height: 1s;
}

/* ── Header ── */

.header {
    height: auto;
    width: 1s;
    child-top: 10px;
    child-bottom: 10px;
    child-left: 16px;
    child-right: 16px;
    col-between: 8px;
    background-color: #2a2a2a;
    border-color: #3a3a3a;
    border-width: 0px 0px 1px 0px;
}

.title {
    color: #f5b342;
    font-size: 16;
    font-weight: bold;
    width: auto;
    height: auto;
}

.subtitle {
    color: #777777;
    font-size: 11;
    width: auto;
    height: auto;
    child-top: 1s;
    child-bottom: 0px;
}

.version {
    color: #555555;
    font-size: 10;
    width: auto;
    height: auto;
    child-left: 1s;
    child-top: 1s;
    child-bottom: 0px;
}

/* ── Parameter grid container ── */

.params-container {
    width: 1s;
    height: 1s;
    child-left: 8px;
    child-right: 8px;
    child-top: 4px;
    child-bottom: 8px;
}

/* ── GenericUi overrides for Ableton look ── */

generic-ui {
    width: 1s;
    height: 1s;
    child-space: 0px;
    row-between: 1px;
}

generic-ui .row {
    width: 1s;
    height: 30px;
    col-between: 4px;
    child-left: 4px;
    child-right: 4px;
    background-color: #2a2a2a;
    border-radius: 2px;
}

generic-ui .row:hover {
    background-color: #333333;
}

generic-ui .row:nth-child(even) {
    background-color: #262626;
}

generic-ui .row:nth-child(even):hover {
    background-color: #333333;
}

generic-ui .row .label {
    color: #999999;
    font-size: 11;
    width: 120px;
    child-left: 8px;
    child-top: 1s;
    child-bottom: 1s;
}

generic-ui .row .widget {
    height: 22px;
    child-top: 1s;
    child-bottom: 1s;
}

/* ── Slider styling ── */

param-slider {
    background-color: #3a3a3a;
    border-radius: 2px;
    color: #e6e6e6;
    font-size: 11;
}

param-slider .fill {
    background-color: #f5b342;
    border-radius: 2px;
}

param-slider:hover .fill {
    background-color: #ffcc5c;
}

param-slider:active .fill {
    background-color: #68ccca;
}

/* ── Footer ── */

.footer {
    height: auto;
    width: 1s;
    child-left: 1s;
    child-right: 1s;
    child-top: 2px;
    child-bottom: 6px;
    border-color: #3a3a3a;
    border-width: 1px 0px 0px 0px;
    col-between: 4px;
}

.footer-text {
    color: #555555;
    font-size: 9;
    width: auto;
    height: auto;
}
"#;

// ── Data model ──────────────────────────────────────────────────────────────

#[derive(Lens)]
struct Data {
    params: Arc<MothParams>,
}

impl Model for Data {}

// ── Public API ──────────────────────────────────────────────────────────────

pub(crate) fn default_state() -> Arc<ViziaState> {
    ViziaState::new(|| (EDITOR_WIDTH, EDITOR_HEIGHT))
}

pub(crate) fn create(
    params: Arc<MothParams>,
    editor_state: Arc<ViziaState>,
) -> Option<Box<dyn Editor>> {
    create_vizia_editor(editor_state, ViziaTheming::Custom, move |cx, _| {
        assets::register_noto_sans_light(cx);
        assets::register_noto_sans_thin(cx);

        cx.add_stylesheet(STYLE).expect("moth: stylesheet");

        Data {
            params: params.clone(),
        }
        .build(cx);

        VStack::new(cx, |cx| {
            // ── Header ──
            HStack::new(cx, |cx| {
                Label::new(cx, "MOTH").class("title");
                Label::new(cx, "physical modelling synthesiser").class("subtitle");
                Label::new(cx, "v0.3.0").class("version");
            })
            .class("header");

            // ── Parameter grid ──
            ScrollView::new(cx, 0.0, 0.0, false, true, |cx| {
                GenericUi::new(cx, Data::params);
            })
            .class("params-container");

            // ── Footer ──
            HStack::new(cx, |cx| {
                Label::new(cx, "RYO Modular  \u{2014}  exciter \u{2192} vibrator \u{2192} body \u{2192} nonlin \u{2192} spatial \u{2192} out")
                    .class("footer-text");
            })
            .class("footer");
        })
        .class("moth-root");

        ResizeHandle::new(cx);
    })
}
